#pragma once
enum class TypUJ
{
	OBEC,
	OKRES,
	KRAJ,
	KRAJINA
};